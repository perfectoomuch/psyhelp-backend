import { Module } from '@nestjs/common';

@Module({
  controllers: [],
  providers: [],
})
export class TelegramModule {}
