import { Inject, Injectable, LoggerService } from '@nestjs/common';
import { BidRepository } from '../repo/bid/repository';

@Injectable()
export class BidService {
  constructor(
    @Inject('IBidRepository') private readonly bidRepo: BidRepository,
    private readonly logger: LoggerService,
  ) {}

  async create() {}
}
