export enum BidStatusEnum {
  IN_AGREEMENT = 'in_agreement',
  CANCELLED = 'cancelled',
  CONFIRMED = 'confirmed',
}
