import { Inject, Injectable, LoggerService } from '@nestjs/common';
import { TransactionRepository } from '../repo/transaction/repository';

@Injectable()
export class TransactionService {
  constructor(
    @Inject('ITransactionRepository')
    private readonly transactionRepo: TransactionRepository,
    private readonly logger: LoggerService,
  ) {}
}
